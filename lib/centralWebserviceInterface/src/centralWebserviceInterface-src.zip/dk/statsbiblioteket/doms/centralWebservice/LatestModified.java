
package dk.statsbiblioteket.doms.centralWebservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LatestModified complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LatestModified">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="collectionPid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="viewAngle" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="entryContentModel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LatestModified", propOrder = {
    "collectionPid",
    "viewAngle",
    "entryContentModel"
})
public class LatestModified {

    @XmlElement(required = true)
    protected java.lang.String collectionPid;
    @XmlElement(required = true)
    protected java.lang.String viewAngle;
    @XmlElement(required = true)
    protected java.lang.String entryContentModel;

    /**
     * Gets the value of the collectionPid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getCollectionPid() {
        return collectionPid;
    }

    /**
     * Sets the value of the collectionPid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setCollectionPid(java.lang.String value) {
        this.collectionPid = value;
    }

    /**
     * Gets the value of the viewAngle property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getViewAngle() {
        return viewAngle;
    }

    /**
     * Sets the value of the viewAngle property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setViewAngle(java.lang.String value) {
        this.viewAngle = value;
    }

    /**
     * Gets the value of the entryContentModel property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getEntryContentModel() {
        return entryContentModel;
    }

    /**
     * Sets the value of the entryContentModel property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setEntryContentModel(java.lang.String value) {
        this.entryContentModel = value;
    }

}
